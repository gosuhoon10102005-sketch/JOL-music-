MY PERSONAL MUSIC WEB APP — GREEN & BLACK

Files:
- index.html: music player, local audio library, lyrics editor, direct audio URL import
- manifest.json: installable web app metadata
- sw.js: caches app shell for offline opening
- icon.svg: app icon

HOSTING (GitHub Pages):
1. Extract this ZIP on a computer.
2. Sign in to GitHub and create a new public repository, e.g. my-music.
3. Choose Add file > Upload files; upload all four files from the extracted folder (not the ZIP itself), then Commit changes.
4. Open repository Settings > Pages. Under Build and deployment choose Deploy from a branch; select main and /(root), then Save.
5. Wait for the published URL, usually https://YOUR-USERNAME.github.io/my-music/ .
6. Open that URL in iPhone Safari while online. Tap Share > Add to Home Screen > Add.
7. Open the Home Screen icon once while online. Add audio files and wait until saved. Test offline by enabling Airplane Mode and reopening the app.

NOTES:
- This is a static web app; no account/server is needed for songs, which are stored locally in the browser on that device.
- iOS/browser storage can be removed by the user or system. Keep original audio files in Files as backups.
- Direct URL import works only if the audio URL is publicly reachable and its server permits browser cross-origin fetch (CORS). If it fails, open the link and save the audio to Files, then import it using the file picker.
- Use only audio files you own or have permission to download.
- Service workers require HTTPS (GitHub Pages provides HTTPS). Offline app shell is cached; local imported songs are saved separately in IndexedDB.
